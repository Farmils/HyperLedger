'use strict';

const TokenERC20 = require('./tokenERC20');
const TokenFunctions = require('./Users.js');

module.exports.TokenERC20 = TokenERC20;
module.exports.TokenFunctions = TokenFunctions;
module.exports.contracts = [TokenERC20, TokenFunctions];
